<?php
print_r($_GET);//http://test1.ru/php/l2/handler.php?imya=&surname=
print_r($_POST); //http://test1.ru/php/l2/handler.php
?>