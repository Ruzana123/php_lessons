<form action="http://test1.ru/php/l2/handler.php" method="POST"> <!---путь куди відсил данні з форми-->
	<p>
		<label for="name">Name</label><br>
		<input type="text" name="imya">
	</p>
	<p>
		<label for="name">Surname</label><br>
		<input type="text" name="surname">
	</p>
	<button type="submit">Submit form</button>
</form>
