<pre>
	<h1>
		City here is, <?php echo $_GET['name']
	?>
	</h1>
	<?php
	?>
</pre>