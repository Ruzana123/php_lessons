<?php
$cities = array( 
'Uman' => 'Uman', 
'Kyiv' => 'Kyiv', 
'Odesa' => 'Odesa', 
'Lviv' => 'Lviv', 
);
?>