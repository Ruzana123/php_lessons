
<?php
?>
<form action="http://test1.ru/php/l2/homework/fio.php" method="POST"> <!---путь куди відсил данні з форми-->
	<p>
		<label for="last_name">Last name</label><br>
		<input type="text" name="last_name">
	</p>
	<p>
		<label for="imya">Name</label><br>
		<input type="text" name="imya">
	</p>
	<p>
		<label for="surname">Surname</label><br>
		<input type="text" name="surname">
	</p>
	<button type="submit">Short FIO</button>
</form>
<?php
?>
