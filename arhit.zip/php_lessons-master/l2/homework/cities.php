<?php  
$cities="Kyiv,Uman,Odessa,Talne,Chernihiv";
$city = explode(",", $cities);
?>