<form action="http://test1.ru/php/l2/cart.php" method="POST">
	<p>
		<label for="name">Name</label><br>
		<input type="text" name="imya">
	</p>
	<p>
		<label for="age">Age</label><br>
		<input type="text" name="age">
	</p>
	<p>
		<label for="position">Position</label><br>
		<input type="text" name="position">
	</p>
	<p>
		<label for="link">Lnk_VK</label><br>
		<input type="text" name="link">
	</p>
	<button type="submit">Submit form</button>
</form>