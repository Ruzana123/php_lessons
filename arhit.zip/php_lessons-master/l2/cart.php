<pre>
<?php

?>
<table>
	<tr>
		<td>
			<h1><?php echo $_POST['name'],'<br>'?></h1>
			<?php echo $_POST['position'],'<br>'?>
			<?php echo $_POST['age'],'<br>'?>
			<a href="<?php echo $_POST['link']?>">link</a>
		</td>
	</tr>
		
</table>
<?php
?>
</pre>