<?php
?>
<form action="http://test1.ru/php/l3/zad/hundler.php" method="POST"> <!---путь куди відсил данні з форми-->
	<p>
		<label for="name">Name</label><br>
		<input type="text" name="name">
	</p>
	<p>
		<label for="email">Email</label><br>
		<input type="text" name="email">
	</p>
	<button type="submit">Short FIO</button>
</form>
<pre>
<?php
?>
</pre>