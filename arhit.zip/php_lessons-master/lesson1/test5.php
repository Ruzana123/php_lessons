<pre>
<?php
//if-else
$i=0;
$x=true;
	while ( $x) {
		echo 'va' .$i .'<br>';
		$i=$i+1;
		if ($i>5){
			$x=false;
		}
	}


	foreach ($variable as $key => $value) {
		# code...
	}


	for ($i=0; $i < ; $i++) { 
		# code...
	}


	do while ( <= 10) {
		# code...
	}


?>
</pre>