
<?php
$product=array(
		array(
			'img_src'=>'pr.png',
			'name'=>'Soft ruckzack',
			'old-price'=>'$128.00',
			'new-price'=>'$79.00',
		),
		array(
			'img_src'=>'pr.png',
			'name'=>'Soft ruckzack1',
			'old-price'=>'$128.00',
			'new-price'=>'$79.00',
		),
		array(
			'img_src'=>'pr.png',
			'name'=>'Soft ruckzack2',
			'old-price'=>'$128.00',
			'new-price'=>'$79.00',
		),
		array(
			'img_src'=>'pr.png',
			'name'=>'Soft ruckzack3',
			'old-price'=>'$128.00',
			'new-price'=>'$79.00',
		),
		array(
			'img_src'=>'pr.png',
			'name'=>'Soft ruckzack4',
			'old-price'=>'$128.00',
			'new-price'=>'$79.00',
		),
		array(
			'img_src'=>'pr.png',
			'name'=>'Soft ruckzack5',
			'old-price'=>'$128.00',
			'new-price'=>'$79.00',
		),
		array(
			'img_src'=>'pr.png',
			'name'=>'Soft ruckzack6',
			'old-price'=>'$128.00',
			'new-price'=>'$79.00',
		),
	);

?>
