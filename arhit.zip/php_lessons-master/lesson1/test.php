<?php
$name='Maxim';
echo "name".$name;
echo '<p>123</p>';
$a=10;
$b=10.10;
$x=true; //false 

$c='5';
$k=$a+$c;
echo $k;
echo gettype($c);  //виводить тип перемінної
$m=(int)'5'; 
echo gettype($m); 


//масиви
$array=array(1,2,5);
print_r($array);
var_dump($array);



?>