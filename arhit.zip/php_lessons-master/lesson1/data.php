<pre>
<?php
$lang2=array('html'=>'HTML',
	'css'=>'CSS',
	'js'=>'JS',
	'c'=>array(
		'va',
		'vaaa'
		)
	);

?>
</pre>