<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title> New_pages </title>
</head>
<body>
	
	<a href="2z.php"> Назад </a>

</body>
</html>