<?php
	header("Location: 2z_page.php");
?>