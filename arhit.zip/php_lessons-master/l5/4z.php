<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
	</head>
	<body>
		<form action="test4.php" method="POST"> <!---путь куди відсил данні з форми пишеться в action=' '-->
			<p>
				<label for="str">Enter the link to the page</label><br>
				<input type="text" name="str">
			</p>
			<button type="submit">Рerform</button>
		</form>
	</body>
</html>

