<?php 
include 'function.php';
rz_chessboard();
?>