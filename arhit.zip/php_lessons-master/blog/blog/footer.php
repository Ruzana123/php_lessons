<footer>
			<div class="footer-main">
				<div class="container">
					<div class="row">
						<div class="col-md-4 col-sm-6 footer-block">
							<div class="about-corp">
								<h4 class="footer-h4 first-footer-title yelow-line">Creative Agency from London - UK</h4>
								<p class="alignment1">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
								<a href="index.html" class="logo-f"><img src="images/main/footer-logo.png" alt=""></a>
							</div>
						</div>
						<div class="col-md-2 col-sm-6 footer-block">
							<h4 class="footer-h4 yelow-line">Links</h4>
							<ul class="footer-menu">
								<li><a href="#">Theme features</a></li>
								<li><a href="#">Page builder</a></li>
								<li><a href="#">Private policy</a></li>
								<li><a href="#">Shop ruler</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">Gallery layout</a></li>
							</ul>
						</div>
						<div class="col-md-3 col-sm-6 footer-block">
							<h4 class="footer-h4 yelow-line">Twitter widget</h4>
							<div class="alignment">
								<div class="footer-info-post">
									<p>Looking for an awesome CREATIVE WordPress Theme? Esquise was updated and optimized to run even better. Find it here: <a href="#">http://t.co/0WWEMQEQ48</a></p>
									<i class="fa fa-twitter"></i>
									<span>
										01 day ago
									</span>
								</div>
								<div class="footer-info-post">
									<p>It is a long established fact that a reader will be distracted by the readable. Find it here: <a href="#">http://t.co/0WWEMQEQ48</a></p>
									<i class="fa fa-twitter"></i>
									<span>
										02 day ago
									</span>
								</div>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 footer-block">
							<h4 class="footer-h4 yelow-line">Instagram</h4>
							<div class="col-md-12 img-tab-f">
								<ul class="alignment4">
									<li>
										<a class="footer-img" href="#"><img src="images/main/bg5.png" alt=""></a>
									</li>
									<li>
										<a class="footer-img" href="#"><img src="images/main/bg5.png" alt=""></a>
									</li>
									<li>
										<a class="footer-img" href="#"><img src="images/main/bg5.png" alt=""></a>
									</li>
									<li>
										<a class="footer-img" href="#"><img src="images/main/bg5.png" alt=""></a>
									</li>
									<li>
										<a class="footer-img" href="#"><img src="images/main/bg5.png" alt=""></a>
									</li>
									<li>
										<a  class="footer-img" href="#"><img src="images/main/bg5.png" alt=""></a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="copyright">
				<div class="container">
					<div class="row footer-main">
						<div class="col-md-8 col-sm-6 col-xs-12 left-footer">
							<span>© 2015 ZAP CREATIVE PSD TEMPLATE. Powered By WPELITE</span>
						</div>
						<div class="col-md-4 col-sm-6 col-xs-12 right-footer">
							<ul>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-globe"></i></a></li>
								<li><a href="#"><i class="fa fa-behance"></i></a></li>
								<li><a href="#"><i class="fa fa-pinterest-p"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- end footer -->
		<script src="js/jquery-1.11.3.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.magnific-popup.js"></script>
		<script src="js/jquery.vide.min.js"></script>
		<script src="js/owl.carousel.js"></script>
		<script src="js/jquery-ui.js"></script>
		<script src="js/main.js"></script>
		<script src="js/classie.js"></script>
		<script>
		$('#open-popup').magnificPopup({
		    items: [

		      {
		        src: 'va.mp4',
		        type: 'iframe' // this overrides default type
		      },

		    ],   

		});
		</script>
	</body>
</html>