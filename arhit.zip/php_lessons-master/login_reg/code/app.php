<?php
	include "router.php";
	include "controller.php";
	include "functions.php";
?>