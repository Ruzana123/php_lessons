<?php include "code/app.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" integrity="sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7" crossorigin="anonymous">
</head>
<body style="background-image: url(fon.jpg);">
	<div class="container" style="background-color: rgba(23, 13, 15, 0.4); color:white;">
		<a href="?action=login" title="Login" style="font-size:18px;"> Login </a><br>
	    <a href="?action=reg" title="Reg" style="font-size:18px;"> Registration </a><br>
	    <a href="?comments=showComments" title="Follow to comments" style="font-size:18px;"> Follow to comments </a><br><br>
	<?php
		router();
	?>
	</div>

</body>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" integrity="sha384-0mSbJDEHialfmuBBQP6A4Qrprq5OVfW37PRR3j5ELqxss1yVqOtnepnHVP9aJ7xS" crossorigin="anonymous"></script>
</html>